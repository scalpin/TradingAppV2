﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.Models
{
    public class Security
    {
        public string FinamToken { get; set; } = "";
        public string TinkoffToken { get; set; } = "";
        public string FinamClientId { get; set; } = "";
    }
}
