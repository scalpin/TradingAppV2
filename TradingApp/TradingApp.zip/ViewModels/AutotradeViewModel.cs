﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Threading.Tasks;
using System.Text;
using TradingApp.Services;
using TradingApp.Helpers;
using Tinkoff.InvestApi.V1;
using System.Collections.ObjectModel;

namespace TradingApp.ViewModels
{
    public class AutoTradeViewModel
    {

    }
}